import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,writeFile,readFile,rename} from 'node:fs/promises';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const directory=await mkdtemp(resolve('.local/rename-repro-'));
const path=resolve(directory,'owner.json');
await writeFile(path,'{"old":true}');await writeFile(path+'.tmp','{"new":true}');
const script='$converterLock = [System.IO.File]::Open($env:MEMORIA_RENAME_TEST_FILE, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite); try { [Console]::WriteLine("LOCKED"); [Console]::ReadLine() | Out-Null } finally { $converterLock.Dispose() }';
const p=spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,stdio:['pipe','pipe','pipe'],env:{...process.env,MEMORIA_RENAME_TEST_FILE:path},timeout:10000});
const ended=once(p,'exit');
try {
  const [chunk]=await once(p.stdout,'data');assert(chunk.toString().includes('LOCKED'));
  let observed;
  try{await rename(path+'.tmp',path);}catch(e){observed=e.code;}
  assert.equal(observed,'EPERM');
  assert.equal(await readFile(path,'utf8'),'{"old":true}');
  p.stdin.end('\n');await ended;
  await rename(path+'.tmp',path);assert.equal(await readFile(path,'utf8'),'{"new":true}');
  console.log(JSON.stringify({reader:'Windows FileShare.ReadWrite without Delete',observed,afterReaderRelease:'atomic rename succeeds',oldTargetPreserved:true}));
} finally {if(p.exitCode===null){p.stdin.end('\n');await ended;}}
