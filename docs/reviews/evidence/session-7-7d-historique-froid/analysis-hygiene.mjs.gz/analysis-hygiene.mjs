import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const campaigns=['2026-11-06T22-45-49-372Z','2026-11-06T22-49-37-897Z','2026-11-06T22-58-03-573Z'];
const results=[];
for(const id of campaigns){
 const root=`.local/3d-alternating/${id}`,manifest=JSON.parse(await readFile(`${root}/manifest.json`));
 const pre=[],post=[],wsl=[];let intervals=0;
 for(const s of manifest.series){
  assert.equal(s.code,0);assert.equal(s.hygiene.assessment.valid,true);
  assert.equal(s.hygiene.assessment.deltaInPages,0);assert.equal(s.hygiene.assessment.deltaOutPages,0);
  pre.push(s.preparation.observation.windowsFreeBytes);
  intervals+=s.hygiene.assessment.intervals;
  const report=JSON.parse(await readFile(`${root}/${s.configuration}-${s.suite}-${s.iteration}.json`));
  for(const p of report.reports){
   const o=p.memoryAfterPreparation;post.push(o.windowsFreeBytes);wsl.push(o.wsl.memAvailableBytes);
   assert(o.power.batteries.every(b=>b.BatteryStatus===2));
   assert.equal(p.warmup,2);assert.equal(p.iterations,30);assert(p.p95<500);
  }
  assert(s.preparation.observation.power.batteries.every(b=>b.BatteryStatus===2));
 }
 const result={id,series:manifest.series.length,intervals,minWindowsBeforeGiB:Math.min(...pre)/1024**3,minWindowsAfterGiB:Math.min(...post)/1024**3,minWslAfterGiB:Math.min(...wsl)/1024**3};
 assert(result.minWindowsBeforeGiB>=3);assert(result.minWindowsAfterGiB>=1.5);assert(result.minWslAfterGiB>=2);
 await writeFile(`${root}/hygiene-summary.json`,JSON.stringify(result,null,2)+'\n');results.push(result);
}
console.log(JSON.stringify(results));
