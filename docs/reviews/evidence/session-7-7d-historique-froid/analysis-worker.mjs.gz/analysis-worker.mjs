import {readFile,writeFile} from 'node:fs/promises';
const directory=process.argv[2],result=[];
const stats=v=>({mean:v.reduce((a,b)=>a+b,0)/v.length,p95:[...v].sort((a,b)=>a-b)[Math.ceil(v.length*.95)-1]});
for(let series=1;series<=3;series++)for(const version of ['reference','candidate']){
 const report=JSON.parse(await readFile(`${directory}/${version}-cold-${series}-profile.json`,'utf8'));
 const events=report.workerEvents;
 const init=events.filter(e=>e.operation==='init' && report.samples.some(s=>
   e.profile.origin+e.profile.started >= report.origin+s.started &&
   e.profile.origin+e.profile.started <= report.origin+s.ended));
 if(init.length!==64) throw Error(`Expected 64 inits, got ${init.length}`);
 for(const [index,profile] of ['content-1M','history-1M'].entries()){
  const samples=init.slice(index*32+2,index*32+32).map(e=>{
   const p=e.profile;
   const gc=events.filter(v=>v.profile.threadId===p.threadId).flatMap(v=>v.profile.gc)
    .filter(g=>g.start<p.ended && g.start+g.duration>p.started).reduce((sum,g)=>sum+g.duration,0);
   return {...p,gc};
  });
  const stages={};
  for(const name of Object.keys(samples[0].stages)) stages[name]=stats(samples.map(s=>s.stages[name]));
  result.push({series,version,profile,total:stats(samples.map(s=>s.ended-s.started)),gc:stats(samples.map(s=>s.gc)),stages,samples});
 }
}
await writeFile(`${directory}/worker-diagnostic.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.filter(r=>r.profile==='history-1M').map(({samples,...r})=>({...r,slowest:[...samples].sort((a,b)=>(b.ended-b.started)-(a.ended-a.started)).slice(0,2)}))));
