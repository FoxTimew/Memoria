import {readFile,writeFile} from 'node:fs/promises';
const directory=process.argv[2];
const result=[];
const stats=v=>({mean:v.reduce((a,b)=>a+b,0)/v.length,p95:[...v].sort((a,b)=>a-b)[Math.ceil(v.length*.95)-1]});
for(let series=1;series<=3;series++)for(const version of ['reference','candidate']){
 const report=JSON.parse(await readFile(`${directory}/${version}-cold-${series}-profile.json`,'utf8'));
 if(report.samples.length!==64) throw Error('Incomplete profile');
 for(const [index,profile] of ['content-1M','history-1M'].entries()){
  const samples=report.samples.slice(index*32+2,index*32+32).map(s=>({...s,gc:report.gc.filter(g=>g.start<s.ended && g.start+g.duration>s.started).reduce((n,g)=>n+g.duration,0)}));
  const stages={},workers={};
  for(const name of Object.keys(samples[0].stages)) stages[name]=stats(samples.map(s=>s.stages[name]));
  for(const name of Object.keys(samples[0].workers)) workers[name]=stats(samples.map(s=>s.workers[name]));
  result.push({series,version,profile,total:stats(samples.map(s=>s.total)),mainGc:stats(samples.map(s=>s.gc)),stages,workers,slowest:[...samples].sort((a,b)=>b.total-a.total).slice(0,3)});
 }
}
await writeFile(`${directory}/diagnostic.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.map(({slowest,...summary})=>({...summary,slowest:slowest.map(s=>({total:s.total,gc:s.gc,init:s.stages.replicaInit,workerInit:s.workers.init,ledger:s.stages.ledgerTransaction,heapBefore:s.heapBefore,heapAfter:s.heapAfter}))}))));
