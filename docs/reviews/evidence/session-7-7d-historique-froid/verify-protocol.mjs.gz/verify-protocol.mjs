import {readFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=process.argv[2]??'docs/reviews/evidence/session-7-7d-historique-froid';
const manifest=JSON.parse(await readFile(`${root}/manifest.json`));
const read=async name=>gunzipSync(await readFile(`${root}/${name}.gz`));
for(const campaign of manifest.campaigns){
 const names=[`${campaign.tag}-protocol-compare.mjs`,'measurement-power.mjs','measurement-memory.mjs','docker-test-isolation.mjs','measurement-regression.mjs',`${campaign.tag}-protocol-cold-profile.ts`];
 if(campaign.tag==='worker')names.push('worker-protocol-cold-worker-profile.ts');
 const hash=createHash('sha256').update(Buffer.concat(await Promise.all(names.map(read)))).digest('hex');
 assert.equal(hash,campaign.protocolHash,campaign.tag);
 console.log(JSON.stringify({campaign:campaign.tag,protocolHash:hash,verified:true}));
}
