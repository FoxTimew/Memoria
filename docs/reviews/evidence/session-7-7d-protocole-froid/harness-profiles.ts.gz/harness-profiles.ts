import { readFile } from 'node:fs/promises';
export async function loadProfile(profile: string) {
  return readFile(`.local/incremental/${profile}.bin`);
}