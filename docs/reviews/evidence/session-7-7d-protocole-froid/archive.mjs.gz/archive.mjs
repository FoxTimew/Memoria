import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {basename} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const directory=process.argv[2];
const root='docs/reviews/evidence/session-7-7d-protocole-froid';
const files=[],sha=b=>createHash('sha256').update(b).digest('hex');
await mkdir(root,{recursive:true});
async function archive(source,name=basename(source)){
 const bytes=await readFile(source),compressed=gzipSync(bytes),file=name+'.gz';
 await writeFile(`${root}/${file}`,compressed);
 files.push({source,file,bytes:bytes.length,sha256:sha(compressed),uncompressedSha256:sha(bytes)});
}
const manifest=JSON.parse(await readFile(`${directory}/manifest.json`));
const inputs=[];
for(const file of manifest.protocolFiles){
 const bytes=await readFile(`${directory}/${file.file}`);assert.equal(sha(bytes),file.sha256);
 inputs.push(bytes);
}
assert.equal(sha(Buffer.concat(inputs)),manifest.protocolHash);
for(const name of await readdir(directory))if(/\.(json|txt)$/.test(name))await archive(`${directory}/${name}`);
for(const row of manifest.series){
 await archive(row.preparation.path);
 for(const attempt of row.hygiene.attempts)await archive(attempt.path);
}
for(const name of Object.keys(manifest.harness))await archive(`${directory}/sources/candidate/apps/collab/src/testing/${name}`,`harness-${name}`);
for(const name of ['comparison','unit','unit-final','types','check','verdict'])await archive(`.local/session-7-7d-lifecycle-${name}.log`,`${name}.log`);
for(const name of ['report-cold-lifecycle.mjs','verify-cold-lifecycle-harness.mjs','adjudicate-cold-lifecycle.mjs'])await archive(`.local/${name}`,name);
await archive('scripts/collab-comparison.test.mjs','collab-comparison.test.mjs');
await archive('.local/archive-cold-lifecycle.mjs','archive.mjs');
await writeFile(`${root}/manifest.json`,JSON.stringify({date:new Date().toISOString(),commits:manifest.commits,protocolHash:manifest.protocolHash,files},null,2)+'\n');
console.log(JSON.stringify({artifacts:files.length,protocolVerified:true}));
