import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const directory=process.argv[2],read=async name=>JSON.parse(await readFile(`${directory}/${name}`));
const manifest=await read('manifest.json'),summary=await read('summary.json');
assert.equal(manifest.series.length,18);
const pre=[],post=[],wsl=[];let intervals=0;
for(const row of manifest.series){
 assert.equal(row.code,0);assert.equal(row.hygiene.assessment.valid,true);
 assert.equal(row.hygiene.assessment.deltaInPages,0);assert.equal(row.hygiene.assessment.deltaOutPages,0);
 assert(row.battery.batteries.every(b=>b.BatteryStatus===2));
 pre.push(row.preparation.observation.windowsFreeBytes);intervals+=row.hygiene.assessment.intervals;
 const report=await read(`${row.configuration}-${row.suite}-${row.iteration}.json`);
 for(const profile of report.reports){
  const memory=profile.memoryAfterPreparation;
  post.push(memory.windowsFreeBytes);wsl.push(memory.wsl.memAvailableBytes);
  assert(memory.power.batteries.every(b=>b.BatteryStatus===2));
  if(row.suite!=='warm'){assert.equal(profile.samples.length,30);assert.equal(profile.warmup,2);assert(profile.p95<500);}
 }
 if(row.suite==='cold-lifecycle')assert.equal(report.trials.length,64);
}
const hygiene={series:18,intervals,minWindowsBeforeGiB:Math.min(...pre)/1024**3,minWindowsAfterGiB:Math.min(...post)/1024**3,minWslAfterGiB:Math.min(...wsl)/1024**3};
await writeFile(`${directory}/hygiene-summary.json`,JSON.stringify(hygiene,null,2)+'\n');
console.log(JSON.stringify({hygiene,metrics:summary.metrics,supplementary:summary.supplementaryMetrics,failures:summary.failures},null,2));
